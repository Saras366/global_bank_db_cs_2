# Databricks notebook source
# MAGIC %run /Workspace/Users/hemantkhorwal99@gmail.com/Cap_Stone/medallion_architecture/Bronze_Layer

# COMMAND ----------

# MAGIC %run /Workspace/Users/hemantkhorwal99@gmail.com/Cap_Stone/medallion_architecture/Silver_Layer

# COMMAND ----------

try:
    # Run the external notebook
    dbutils.notebook.run("/Workspace/Users/hemantkhorwal99@gmail.com/Cap_Stone/medallion_architecture/Gold_Layer", timeout_seconds=3600)
except Exception as e:
    print(f"Error running the notebook: {e}")
