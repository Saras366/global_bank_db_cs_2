# Databricks notebook source
# MAGIC %md
# MAGIC ##Load the data from bronze layer to silver 

# COMMAND ----------

def load_dataframes():
    # Load the DataFrames
    silver_branch_df = spark.read.table("Bank_Data.bronze.branch_data")
    silver_cust_df = spark.read.table("Bank_Data.bronze.customer_data")
    silver_trans_df = spark.read.table("Bank_Data.bronze.transaction_data")
    
    return silver_branch_df, silver_cust_df, silver_trans_df

# Call the function to load DataFrames
silver_branch_df, silver_cust_df, silver_trans_df = load_dataframes()


# COMMAND ----------

# MAGIC %md
# MAGIC ##Checking the null values and duplicated for customer and transaction table

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, sum
from pyspark.sql.types import StringType, IntegerType, DoubleType
from functools import reduce

# Initialize SparkSession
spark = SparkSession.builder.appName("DataAnalysis").getOrCreate()

def analyze_df(df, df_name):
    """Analyze DataFrame to check for null values, duplicates, and data types."""
    # Calculate total rows
    total_rows = df.count()
    
    # Calculate null values
    null_counts = df.select([sum(col(c).isNull().cast("int")).alias(c) for c in df.columns]).collect()[0].asDict()
    null_percentages = {c: round((count / total_rows) * 100, 2) for c, count in null_counts.items()}
    
    # Calculate duplicates
    duplicate_counts = df.groupBy(df.columns).count().filter("count > 1").count()
    
    # Data type information
    data_types = {field.name: field.dataType.simpleString() for field in df.schema.fields}
    
    # Create DataFrames for null values, duplicates, and data types
    null_result_df = spark.createDataFrame(
        [(df_name, col_name, null_counts[col_name], null_percentages[col_name]) for col_name in df.columns],
        ["DataFrame", "Column", "NullCount", "NullPercentage"]
    )
    
    duplicate_result_df = spark.createDataFrame(
        [(df_name, duplicate_counts)],
        ["DataFrame", "DuplicateCount"]
    )
    
    datatype_result_df = spark.createDataFrame(
        [(df_name, col_name, dtype) for col_name, dtype in data_types.items()],
        ["DataFrame", "Column", "DataType"]
    )
    
    return null_result_df, duplicate_result_df, datatype_result_df

def analyze_multiple_dfs(dfs):
    """Analyze multiple DataFrames."""
    all_null_results = []
    all_duplicate_results = []
    all_datatype_results = []
    
    for df_name, df in dfs.items():
        null_result_df, duplicate_result_df, datatype_result_df = analyze_df(df, df_name)
        all_null_results.append(null_result_df)
        all_duplicate_results.append(duplicate_result_df)
        all_datatype_results.append(datatype_result_df)
    
    # Combine results
    final_null_result_df = reduce(lambda a, b: a.union(b), all_null_results)
    final_duplicate_result_df = reduce(lambda a, b: a.union(b), all_duplicate_results)
    final_datatype_result_df = reduce(lambda a, b: a.union(b), all_datatype_results)
    
    return final_null_result_df, final_duplicate_result_df, final_datatype_result_df


# Analyze multiple DataFrames
dfs = {
    "silver_cust_df": silver_cust_df,
    "silver_trans_df": silver_trans_df
}

final_null_result_df, final_duplicate_result_df, final_datatype_result_df = analyze_multiple_dfs(dfs)

# Display the results
display(final_null_result_df)
display(final_duplicate_result_df)
display(final_datatype_result_df)



# COMMAND ----------

# MAGIC %md
# MAGIC ## Rules for cleaning data for customer df and transaction df

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when, regexp_replace, regexp_extract, length, sum, lit
from pyspark.sql.types import IntegerType
from functools import reduce

# Initialize SparkSession
spark = SparkSession.builder.appName("DataCleaning").getOrCreate()

def remove_duplicates(df):
    """Remove duplicate rows from the DataFrame."""
    df = df.dropDuplicates()
    print("After removing duplicates:")
    df.display()
    print(f"Count after removing duplicates: {df.count()}")
    return df


def validate_data(df):
    """Validate data by applying necessary conditions."""
    df = df.filter(col("email").rlike(r"^[^@]+@[^@]+\.[^@]+$"))
    print("After validating data:")
    df.display()
    print(f"Count after validating data: {df.count()}")
    return df


def verify_data(df):
    """Verify data to ensure consistency and correctness."""
    valid_credit_score_df = df.filter((col("credit_score").between(0, 850)))
    valid_phone_df = valid_credit_score_df.filter(
        length(regexp_replace(col("phone"), r"\D", "")) == 10
    )
    print("After verifying data:")
    valid_phone_df.display()
    print(f"Count after verifying data: {valid_phone_df.count()}")
    return valid_phone_df

def handle_missing_values(df):
    """Handle missing values in the DataFrame."""
    df = df.fillna({
        'phone': 'Unknown',
        'address': 'Not Provided',
        'credit_score': 0
    })
    print("After handling missing values:")
    df.display()
    print(f"Count after handling missing values: {df.count()}")
    return df

def correct_typos(df):
    """Correct typos and inaccuracies in the DataFrame."""
    df = df.withColumn("name", regexp_replace(col("name"), r"\bMister\b", "Mr."))
    print("After correcting typos:")
    df.display()
    print(f"Count after correcting typos: {df.count()}")
    return df

def address_outliers(df):
    """Address outliers in the DataFrame."""
    df = df.withColumn("credit_score", 
                        when(col("credit_score") > 850, 850)
                        .when(col("credit_score") < 0, 0)
                        .otherwise(col("credit_score")))
    print("After addressing outliers:")
    df.display()
    print(f"Count after addressing outliers: {df.count()}")
    return df

def convert_data_types(df):
    """Convert data types in the DataFrame."""
    df = df.withColumn("credit_score", col("credit_score").cast(IntegerType()))
    print("After converting data types:")
    df.display()
    print(f"Count after converting data types: {df.count()}")
    return df

def handle_special_characters(df):
    """Handle special characters and symbols."""
    df = df.withColumn("address", regexp_replace(col("address"), r"[^\w\s]", "")) \
           .withColumn("phone", regexp_replace(col("phone"), r"[^\d]", ""))
    print("After handling special characters:")
    df.display()
    print(f"Count after handling special characters: {df.count()}")
    return df

def conform_to_privacy_regulations(df):
    """Conform to data privacy regulations."""
    df = df.withColumn("email", regexp_replace(col("email"), r"(\S{2})\S+(@\S+)", "$1***$2"))
    print("After conforming to privacy regulations:")
    df.display()
    print(f"Count after conforming to privacy regulations: {df.count()}")
    return df

def sort_data(df):
    """Sort data by specified columns."""
    df = df.orderBy("last_update", ascending=False)
    print("After sorting data:")
    df.display()
    print(f"Count after sorting data: {df.count()}")
    return df

def parse_address(df):
    """Parse the address into City, State, and ZIP Code columns."""
    city_pattern = r"^(.*)\s+\b[A-Z]{2}\b\s+\d{5}(?:-\d{4})?$"
    state_pattern = r"\b[A-Z]{2}\b"
    zipcode_pattern = r"\b\d{5}(?:-\d{4})?\b"
    
    df = df.withColumn("City", regexp_extract(col("address"), city_pattern, 1))
    df = df.withColumn("State", regexp_extract(col("address"), state_pattern, 0))
    df = df.withColumn("ZIP Code", regexp_extract(col("address"), zipcode_pattern, 0))
    
    # Update 'State' based on specific rules
    df = df.withColumn("State", when(col("State") == "AA", "APO")
                                .when(col("State") == "AE", "APO")
                                .when(col("State") == "AP", "APO")
                                .otherwise(col("State")))

    # Drop the 'address' column
    df = df.drop("address")
    
    print("After parsing address:")
    df.display()
    print(f"Count after parsing address: {df.count()}")
    return df


def clean_data(df):
    """Apply all data cleaning functions."""
    df = remove_duplicates(df)
    df = validate_data(df)
    df = verify_data(df)
    df = handle_missing_values(df)
    df = correct_typos(df)
    df = address_outliers(df)
    df = convert_data_types(df)
    df = handle_special_characters(df)
    df = conform_to_privacy_regulations(df)
    df = parse_address(df)  # Added address parsing here
    df = sort_data(df)
    return df

def analyze_df(df, df_name):
    """Analyze DataFrame for null values and duplicates."""
    total_rows = df.count()
    null_counts = df.select([sum(col(c).isNull().cast("int")).alias(c) for c in df.columns]).collect()[0].asDict()
    null_percentages = {c: round((count / total_rows) * 100, 2) for c, count in null_counts.items()}
    duplicate_counts = df.groupBy(df.columns).count().filter("count > 1").count()
    
    null_result_df = spark.createDataFrame(
        [(df_name, col_name, null_counts[col_name], null_percentages[col_name]) for col_name in df.columns],
        ["DataFrame", "Column", "NullCount", "NullPercentage"]
    )
    
    duplicate_result_df = spark.createDataFrame(
        [(df_name, duplicate_counts)],
        ["DataFrame", "DuplicateCount"]
    )
    
    return null_result_df, duplicate_result_df

def analyze_multiple_dfs(dfs):
    """Analyze multiple DataFrames."""
    all_null_results = []
    all_duplicate_results = []
    
    for df_name, df in dfs.items():
        null_result_df, duplicate_result_df = analyze_df(df, df_name)
        all_null_results.append(null_result_df)
        all_duplicate_results.append(duplicate_result_df)
    
    final_null_result_df = reduce(lambda a, b: a.union(b), all_null_results)
    final_duplicate_result_df = reduce(lambda a, b: a.union(b), all_duplicate_results)
    
    return final_null_result_df, final_duplicate_result_df


# COMMAND ----------

# MAGIC %md
# MAGIC ##Caling the functions

# COMMAND ----------

# Initialize Spark session
spark = SparkSession.builder.appName("DataCleaning").getOrCreate()

def remove_null_values(silver_trans_df):
    # Assuming you want to drop rows with any null values
    return silver_trans_df.dropna()

# Load your DataFrame (replace this with your actual data loading code)
silver_cust_df = spark.read.table("Bank_Data.bronze.customer_data")
silver_trans_df = spark.read.table("Bank_Data.bronze.transaction_data")

# Clean the customer data
cleaned_cust_df = clean_data(silver_cust_df)

# Clean the transaction data
cleaned_trans_df = remove_duplicates(silver_trans_df)
cleaned_trans_df.display()
print(f"Count after removing duplicates in transaction data: {cleaned_trans_df.count()}")
cleaned_trans_df = remove_null_values(silver_trans_df)

# Analyze the cleaned data
dfs = {
    "cleaned_cust_df": cleaned_cust_df,
    "cleaned_trans_df": cleaned_trans_df
}

final_null_result_df, final_duplicate_result_df = analyze_multiple_dfs(dfs)

# Display the results
display(final_null_result_df)
display(final_duplicate_result_df)

# Optionally, write the cleaned DataFrame to a new table or storage
# cleaned_cust_df.write.mode("overwrite").saveAsTable("Bank_Data.bronze.cleaned_customer_data")
# cleaned_trans_df.write.mode("overwrite").saveAsTable("Bank_Data.bronze.cleaned_transaction_data")


# COMMAND ----------

# MAGIC %md
# MAGIC ### Implement a real-time fraud detection system based on rule-based flagging and transaction pattern analysis.
# MAGIC

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit, when, current_timestamp, expr, monotonically_increasing_id

# Initialize Spark session
spark = SparkSession.builder.appName("FraudDetection").getOrCreate()

# Load DataFrames
silver_cust_df = spark.read.table("Bank_Data.bronze.customer_data")
silver_trans_df = spark.read.table("Bank_Data.bronze.transaction_data")

def preprocess_transactions(silver_cust_df, silver_trans_df):
    # Alias DataFrames to avoid ambiguity
    silver_cust_df_alias = silver_cust_df.alias("cust")
    silver_trans_df_alias = silver_trans_df.alias("trans")

    # Join transaction DataFrame with customer DataFrame on customer_id
    df_with_customer_id = silver_trans_df_alias.join(silver_cust_df_alias, silver_trans_df_alias["customer_id"] == silver_cust_df_alias["customer_id"], "left") \
                                              .select(silver_trans_df_alias["*"], silver_cust_df_alias["customer_id"].alias("validated_customer_id"))

    # Return DataFrame with existing transaction_id and new validated_customer_id
    return df_with_customer_id

def detect_fraud(df_with_ids):
    # Example rules for fraud detection
    df_with_flags = df_with_ids.withColumn("flag_type",
                                           when(col("amount") > 10000, "unusual_amount")
                                           .when((col("channel") == "ATM") & (col("amount") > 5000), "velocity_check")
                                           .when(col("status") == "pending", "pending_transaction")
                                           .otherwise("no_flag"))
    
    # Add confidence scores based on flag_type
    df_with_flags = df_with_flags.withColumn("confidence_score",
                                             when(col("flag_type") == "unusual_amount", lit(0.75))
                                             .when(col("flag_type") == "velocity_check", lit(0.60))
                                             .when(col("flag_type") == "pending_transaction", lit(0.80))
                                             .otherwise(lit(0.0)))
    
    # Add a timestamp column
    df_with_flags = df_with_flags.withColumn("timestamp", current_timestamp())
    
    return df_with_flags.select(col("validated_customer_id").alias("customer_id"), col("transaction_id"), col("flag_type"), col("confidence_score"), col("timestamp"))

def generate_fraud_report(df_with_flags):
    # Generate unique flag IDs
    df_with_report = df_with_flags.withColumn("unique_id", monotonically_increasing_id()) \
                                  .withColumn("flag_id", expr("concat('F', cast((unique_id % 10000) + 1000 as string))")) \
                                  .drop("unique_id")
    
    fraud_report_df = df_with_report.select("flag_id", "transaction_id", "flag_type", "confidence_score", "timestamp")
    
    return fraud_report_df

# Execute the functions
df_with_ids = preprocess_transactions(silver_cust_df, silver_trans_df)
df_with_flags = detect_fraud(df_with_ids)
fraud_report_df = generate_fraud_report(df_with_flags)

# Display the final DataFrame
fraud_report_df.display(truncate=False)


# COMMAND ----------

# MAGIC %md
# MAGIC ###Develop a customer segmentation system based on transaction behavior and account information.

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit, when, current_date, datediff, expr, max
from pyspark.sql.types import DateType

# Initialize Spark session
spark = SparkSession.builder.appName("CustomerSegmentation").getOrCreate()

# Load DataFrames
silver_cust_df = spark.read.table("Bank_Data.bronze.customer_data")
silver_trans_df = spark.read.table("Bank_Data.bronze.transaction_data")

# Check schema to determine the correct column name for transaction dates
silver_trans_df.printSchema()

# Assuming the correct column is `timestamp`
silver_cust_df = silver_cust_df.withColumn("join_date", col("join_date").cast(DateType()))
silver_trans_df = silver_trans_df.withColumn("timestamp", col("timestamp").cast(DateType()))  # Change this if your column name is different

# Step 1: Calculate Transaction Metrics for Each Customer
transaction_summary = silver_trans_df.groupBy("customer_id") \
    .agg(
        expr("count(*) as transaction_count"),
        expr("sum(amount) as total_amount"),
        expr("max(timestamp) as last_transaction_date")  # Use the correct column name here
    )

# Step 2: Join Customer Data with Transaction Metrics
customer_summary = silver_cust_df.join(transaction_summary, "customer_id", "left") \
    .withColumn("days_since_last_transaction", datediff(current_date(), col("last_transaction_date"))) \
    .withColumn("days_since_joined", datediff(current_date(), col("join_date")))

# Step 3: Define Segmentation Rules
segmentation_df = customer_summary.withColumn("segment_id",
    when(col("total_amount") > 50000, lit("S001"))  # High Value
    .when(col("days_since_joined") <= 30, lit("S002"))  # New User
    .when(col("days_since_last_transaction") > 90, lit("S003"))  # Inactive
    .when(col("credit_score") < 600, lit("S004"))  # Credit Risk
    .when(col("days_since_joined") > 1825, lit("S005"))  # Loyal
    .otherwise(lit("Unknown"))
).withColumn("segment_name",
    when(col("segment_id") == "S001", lit("High_Value"))
    .when(col("segment_id") == "S002", lit("New_User"))
    .when(col("segment_id") == "S003", lit("Inactive"))
    .when(col("segment_id") == "S004", lit("Credit_Risk"))
    .when(col("segment_id") == "S005", lit("Loyal"))
    .otherwise(lit("Unknown"))
).withColumn("segment_description",
    when(col("segment_id") == "S001", lit("Customers with high transaction volume"))
    .when(col("segment_id") == "S002", lit("Customers who joined in last 30 days"))
    .when(col("segment_id") == "S003", lit("No transactions in last 90 days"))
    .when(col("segment_id") == "S004", lit("Customers with low credit scores"))
    .when(col("segment_id") == "S005", lit("Consistent activity for over 5 years"))
    .otherwise(lit("Unknown"))
).withColumn("last_updated", current_date())

# Step 4: Generate Segmentation Report
segmentation_report_df = segmentation_df.select("segment_id", "customer_id", "segment_name", "segment_description", "last_updated")

# Display the final DataFrame
segmentation_report_df.display(truncate=False)


# COMMAND ----------

# MAGIC %md
# MAGIC ##Create latitude and longitude from address 

# COMMAND ----------

import pandas as pd
import requests
import time
from urllib.parse import quote_plus
from pyspark.sql import SparkSession

def get_coordinates(location: str) -> list:
    """
    Fetches coordinates for a given location using the Nominatim API.
   
    Parameters:
    location (str): The location to geocode.
   
    Returns:
    list: A list with latitude and longitude, or [None, None] if not found.
    """
    if not location:
        return [None, None]

    encoded_location = quote_plus(location)  # URL encode the location
    url = f'https://nominatim.openstreetmap.org/search?q={encoded_location}&format=json&addressdetails=1'
    headers = {'User-Agent': 'YourAppName/1.0 (your-email@example.com)'}  # Add your User-Agent header
    max_retries = 5

    for attempt in range(max_retries):
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()  # Raise an HTTPError for bad responses (4xx and 5xx)
            data = response.json()
            
            # Debugging line to print API response
            print(f"API response for '{location}': {data}")
            
            if data and isinstance(data, list) and len(data) > 0:
                lat = data[0].get('lat')
                lng = data[0].get('lon')
                if lat and lng:
                    return [float(lat), float(lng)]
            # If no data or latitude/longitude is missing
            return [None, None]
        except requests.RequestException as e:
            print(f"Request failed: {e}")
            time.sleep(2 ** attempt)  # Exponential backoff

    return [None, None]

# Initialize Spark session (only needed if not already initialized)
spark = SparkSession.builder.appName("GeocodingExample").getOrCreate()

# Convert Spark DataFrame to pandas DataFrame
branch_pd_df = silver_branch_df.toPandas()

# Apply the geocoding function to each location in the pandas DataFrame
branch_pd_df[['latitude', 'longitude']] = branch_pd_df['location'].apply(get_coordinates).apply(pd.Series)

# Convert the pandas DataFrame back to a Spark DataFrame
branch_transformed = spark.createDataFrame(branch_pd_df)

# Show the updated DataFrame
branch_transformed.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ### load the branch table into silver table 

# COMMAND ----------

branch_transformed.write.mode("overwrite").saveAsTable("Bank_Data.silver.cleaned_branch_data")

# COMMAND ----------

# MAGIC %md
# MAGIC ### load the Segmentation table into silver table 

# COMMAND ----------

# DBTITLE 1,Saving table into silver
segmentation_report_df.write.mode("overwrite").saveAsTable("Bank_Data.silver.Segmentation_data")

# COMMAND ----------

# MAGIC %md
# MAGIC ### load the Segmentation table into silver table 

# COMMAND ----------

fraud_report_df.write.mode("overwrite").saveAsTable("Bank_Data.silver.fraud_data")

# COMMAND ----------

# MAGIC %md
# MAGIC ### load the cleaned customer and transaction table into silver table 

# COMMAND ----------

from pyspark.sql.functions import col

# Function to clean column names
def clean_column_names(df):
    for old_name in df.columns:
        new_name = old_name.replace(" ", "_")  # Replace spaces with underscores
        new_name = ''.join(e for e in new_name if e.isalnum() or e == '_')  # Remove invalid characters
        df = df.withColumnRenamed(old_name, new_name)
    return df

# Clean the column names for both DataFrames
cleaned_cust_df = clean_column_names(cleaned_cust_df)
cleaned_trans_df = clean_column_names(cleaned_trans_df)

# COMMAND ----------

# Now you can write the cleaned DataFrames as tables
cleaned_cust_df.write.mode("overwrite").saveAsTable("Bank_Data.silver.cleaned_customer_data")
cleaned_trans_df.write.mode("overwrite").saveAsTable("Bank_Data.silver.cleaned_transaction_data")