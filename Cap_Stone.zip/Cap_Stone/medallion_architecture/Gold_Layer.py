# Databricks notebook source
def load_dataframes():
    # Load the DataFrames
    gold_branch_df = spark.read.table("Bank_Data.silver.cleaned_branch_data")
    gold_cust_df = spark.read.table("Bank_Data.silver.cleaned_customer_data")
    gold_trans_df = spark.read.table("Bank_Data.silver.cleaned_transaction_data")
    gold_seg_df = spark.read.table("Bank_Data.silver.Segmentation_data")
    gold_fraud_df = spark.read.table("Bank_Data.silver.fraud_data")
    
    return gold_branch_df, gold_cust_df, gold_trans_df,gold_seg_df,gold_fraud_df

# Call the function to load DataFrames
gold_branch_df, gold_cust_df, gold_trans_df,gold_seg_df,gold_fraud_df = load_dataframes()


# COMMAND ----------

spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, date_format, sum as sum_, count
from pyspark.sql.types import DateType

# Initialize Spark session
spark = SparkSession.builder.appName("AutomatedReportingSystem").getOrCreate()

# Load DataFrames
def load_dataframes():
    gold_branch_df = spark.read.table("Bank_Data.bronze.branch_data")
    gold_cust_df = spark.read.table("Bank_Data.silver.cleaned_customer_data")
    gold_trans_df = spark.read.table("Bank_Data.silver.cleaned_transaction_data")
    gold_seg_df = spark.read.table("Bank_Data.silver.Segmentation_data")
    gold_fraud_df = spark.read.table("Bank_Data.silver.fraud_data")
    return gold_branch_df, gold_cust_df, gold_trans_df, gold_seg_df, gold_fraud_df

gold_branch_df, gold_cust_df, gold_trans_df, gold_seg_df, gold_fraud_df = load_dataframes()

# Ensure date columns are in DateType format
gold_trans_df = gold_trans_df.withColumn("transaction_date", col("timestamp").cast(DateType()))

# Define functions for generating summaries
def generate_transaction_summary(df, period):
    period_format = {
        "daily": "yyyy-MM-dd",
        "weekly": "yyyy-ww",
        "monthly": "yyyy-MM"
    }
    summary_df = df.groupBy(date_format(col("transaction_date"), period_format[period]).alias(f"{period}_period")) \
                   .agg(
                       count("transaction_id").alias("transaction_count"),
                       sum_("amount").alias("total_amount")
                   )
    return summary_df.withColumn("total_amount", col("total_amount").cast("decimal(18, 2)"))

def generate_fraud_summary(df, period):
    period_format = {
        "daily": "yyyy-MM-dd",
        "weekly": "yyyy-ww",
        "monthly": "yyyy-MM"
    }
    summary_df = df.groupBy(date_format(col("timestamp"), period_format[period]).alias(f"{period}_period")) \
                   .agg(
                       count("transaction_id").alias("fraud_case_count")
                   )
    return summary_df

def generate_segment_summary(df, period):
    period_format = {
        "daily": "yyyy-MM-dd",
        "weekly": "yyyy-ww",
        "monthly": "yyyy-MM"
    }
    summary_df = df.groupBy(date_format(col("last_updated"), period_format[period]).alias(f"{period}_period"), "segment_name") \
                   .agg(
                       count("customer_id").alias("customer_count")
                   )
    return summary_df

# Generate daily, weekly, and monthly summaries
daily_transaction_summary = generate_transaction_summary(gold_trans_df, "daily")
weekly_transaction_summary = generate_transaction_summary(gold_trans_df, "weekly")
monthly_transaction_summary = generate_transaction_summary(gold_trans_df, "monthly")

daily_fraud_summary = generate_fraud_summary(gold_fraud_df, "daily")
weekly_fraud_summary = generate_fraud_summary(gold_fraud_df, "weekly")
monthly_fraud_summary = generate_fraud_summary(gold_fraud_df, "monthly")

daily_segment_summary = generate_segment_summary(gold_seg_df, "daily")
weekly_segment_summary = generate_segment_summary(gold_seg_df, "weekly")
monthly_segment_summary = generate_segment_summary(gold_seg_df, "monthly")

# Store summaries in Delta tables
summary_tables = {
    "daily_transaction_summary": daily_transaction_summary,
    "weekly_transaction_summary": weekly_transaction_summary,
    "monthly_transaction_summary": monthly_transaction_summary,
    "daily_fraud_summary": daily_fraud_summary,
    "weekly_fraud_summary": weekly_fraud_summary,
    "monthly_fraud_summary": monthly_fraud_summary,
    "daily_segment_summary": daily_segment_summary,
    "weekly_segment_summary": weekly_segment_summary,
    "monthly_segment_summary": monthly_segment_summary
}

for table_name, df in summary_tables.items():
    df.write.format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .saveAsTable(f"Bank_Data.gold.{table_name}")

# Display sample visualizations
def display_visualization(df, title):
    display(df)
    print(f"Displaying {title}...")
    
display_visualization(daily_transaction_summary, "Daily Transaction Summary")
display_visualization(weekly_transaction_summary, "Weekly Transaction Summary")
display_visualization(monthly_transaction_summary, "Monthly Transaction Summary")

display_visualization(daily_fraud_summary, "Daily Fraud Summary")
display_visualization(weekly_fraud_summary, "Weekly Fraud Summary")
display_visualization(monthly_fraud_summary, "Monthly Fraud Summary")

display_visualization(daily_segment_summary, "Daily Segment Summary")
display_visualization(weekly_segment_summary, "Weekly Segment Summary")
display_visualization(monthly_segment_summary, "Monthly Segment Summary")


# COMMAND ----------

# MAGIC %md
# MAGIC ##11.	Develop interactive visualizations using Plotly in Databricks notebooks:

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import count

# Group by channel and count transactions
df_channel_summary = gold_trans_df.groupBy("channel").agg(
    count("transaction_id").alias("transaction_count")
)

# Display the aggregated data
display(df_channel_summary)


# COMMAND ----------

# Example data for segments
df_segment_summary = gold_seg_df.groupBy("segment_name").agg(
    count("customer_id").alias("customer_count")
).toPandas()

# Plotly chart
fig_segment = px.pie(df_segment_summary, names='segment_name', values='customer_count',
                     title='Customer Segment Distribution',
                     labels={'segment_name': 'Segment', 'customer_count': 'Customer Count'})

fig_segment.show()


# COMMAND ----------

from pyspark.sql import functions as F

df_trans_time_series = gold_trans_df.groupBy(F.date_format("timestamp", "yyyy-MM-dd").alias("date")).agg(
    F.count("timestamp").alias("transaction_count"),
    F.sum("amount").alias("total_amount")
).orderBy("date")

# Display the aggregated data
display(df_trans_time_series)


# COMMAND ----------

# import pandas as pd
# import plotly.express as px
# from pyspark.sql import SparkSession

# # Convert the Spark DataFrame to a Pandas DataFrame
# df_branch_geo = gold_branch_df.select("branch_id", "name", "location", "latitude", "longitude").toPandas()

# # Check the first few rows of the DataFrame to ensure it has been converted correctly
# print(df_branch_geo.head())

# # Create the Plotly map
# fig_branch_geo = px.scatter_geo(df_branch_geo, 
#                                 lat='latitude', 
#                                 lon='longitude', 
#                                 hover_name='name',
#                                 title='Geographical Distribution of Branches',
#                                 labels={'latitude': 'Latitude', 'longitude': 'Longitude', 'name': 'Branch Name'})

# # Display the figure
# fig_branch_geo.show()


# COMMAND ----------

import pandas as pd
import plotly.express as px

# Assume gold_trans_df is your DataFrame
# gold_trans_df = ... (your existing DataFrame)

# Convert the PySpark DataFrame to a Pandas DataFrame for value_counts()
gold_trans_pd = gold_trans_df.toPandas()

# Count transactions by mode (using 'channel' column)
mode_counts = gold_trans_pd['channel'].value_counts()

# Calculate the total number of transactions using .count() method
total_transactions = gold_trans_df.count()

# Calculate the popularity (percentage) of each mode
popularity = (mode_counts / total_transactions) * 100

# Print the popularity of each transaction mode
print("Popularity of each transaction mode:")
print(popularity)

# COMMAND ----------

gold_branch_df.write.mode("overwrite").saveAsTable("Bank_Data.gold.gold_branch_df_new")
gold_cust_df.write.mode("overwrite").saveAsTable("Bank_Data.gold.gold_cust_df_new")
gold_trans_df.write.mode("overwrite").saveAsTable("Bank_Data.gold.gold_trans_df")
gold_seg_df.write.mode("overwrite").saveAsTable("Bank_Data.gold.gold_seg_df")
gold_fraud_df.write.mode("overwrite").saveAsTable("Bank_Data.gold.gold_fraud_df")
