# Databricks notebook source
# MAGIC %md
# MAGIC #Bronza Data ingestion 

# COMMAND ----------

# MAGIC %md
# MAGIC ## External Location Path using conf file

# COMMAND ----------

import json
from pyspark.sql import SparkSession

# Define the path to the JSON configuration file
config_file_path = '/Workspace/Users/hemantkhorwal99@gmail.com/Cap_Stone/conf-file/conf.json'

# Load the configuration from the JSON file
with open(config_file_path) as f:
    config = json.load(f)

# Extract details
storage_account = config['ADLS']['storage_account']
container_name = config['ADLS']['container_name']
storage_account_conf_key = config['ADLS']['configuration']['storage_account_conf_key']
storage_account_conf_key_value = config['ADLS']['configuration']['storage_account_conf_key_value']

# Set Spark configuration for ADLS
spark.conf.set(storage_account_conf_key, storage_account_conf_key_value)

# Create the ADLS path
bank_ext_location = f"abfss://{container_name}@{storage_account}.dfs.core.windows.net/"
print(bank_ext_location)


# COMMAND ----------

# MAGIC %md
# MAGIC ##Catalog creation

# COMMAND ----------

#%run "/Workspace/Users/hemantkhorwal99@gmail.com/Cap_Stone/medallion_architecture/Catalogs"

# COMMAND ----------

# MAGIC %md
# MAGIC ##Data Ingestion from adls to bronze layer

# COMMAND ----------

# MAGIC %md
# MAGIC ###Load the data which is constant -- branch table

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType, TimestampType

# Define schema for Branch table
branch_schema = StructType([
    StructField("branch_id", StringType(), True),
    StructField("name", StringType(), True),
    StructField("location", StringType(), True),
    StructField("timezone", StringType(), True)
])
file_names ="/branches_directory/*.csv"
branch_dataset_path = f"abfss://{container_name}@{storage_account}.dfs.core.windows.net/{file_names}"
branch_df = spark.read.csv(path=branch_dataset_path,header=True,schema=branch_schema)
print(f"Total no of records:{branch_df.count()}")
branch_df.write.mode("overwrite").saveAsTable("Bank_Data.bronze.branch_data")


# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC ###Load the data which is streaming tables - customer and transaction

# COMMAND ----------

# MAGIC %md
# MAGIC ####customers table

# COMMAND ----------

def ingest_customer():
    schema = """
    customer_id STRING,
    name STRING,
    email STRING,
    phone STRING,
    address STRING,
    credit_score INT,
    join_date DATE,
    last_update TIMESTAMP
    """

    source_customer_df = (
        spark.readStream.format("csv")
        .option("header", "true")
        .schema(schema)
        .load(f"{bank_ext_location}/customers_directory")
    )

    write_query = (
        source_customer_df.writeStream.format("delta")
        .option("checkpointLocation", f"{bank_ext_location}/customers_directory/checkpoint/")
        .outputMode("append")
        .trigger(availableNow=True)  # Adjust the trigger interval as needed
        .toTable("Bank_Data.bronze.customer_data")
    )

    # Keep the job running
    write_query.awaitTermination()

# Run the ingestion function
ingest_customer()


# COMMAND ----------

ingest_customer()

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT count(*) from Bank_Data.bronze.customer_data;

# COMMAND ----------

# MAGIC %md
# MAGIC ####Transaction Table

# COMMAND ----------

def ingest_transactions():
    # Define the schema for the transaction data
    schema = """
    transaction_id STRING,
    customer_id STRING,
    branch_id STRING,
    channel STRING,
    transaction_type STRING,
    amount DOUBLE,
    currency STRING,
    timestamp TIMESTAMP,
    status STRING
    """

    # Create a streaming DataFrame from the CSV files in the directory
    source_transaction_df = (
        spark.readStream.format("csv")
        .option("header", "true")
        .schema(schema)
        .load(f"{bank_ext_location}/transactions_directory")
    )

    # Write the streaming DataFrame to a Delta table
    write_query = (
        source_transaction_df.writeStream.format("delta")
        .option("checkpointLocation", f"{bank_ext_location}/transactions_directory/checkpoint/")
        .outputMode("append")
        .trigger(availableNow=True)  # Adjust the trigger interval as needed
        .toTable("Bank_Data.bronze.transaction_data")
    )

    # Keep the job running
    write_query.awaitTermination()

# Call the ingestion function
ingest_transactions()


# COMMAND ----------

ingest_transactions()

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT count(*) from Bank_Data.bronze.transaction_data;