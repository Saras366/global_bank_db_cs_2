# Databricks notebook source
try:
    spark.sql("create catalog Bank_Data;")
except:
    print('catalog already exists')

try:
    spark.sql("create schema Bank_Data.bronze;")
except:
    print('bronze schema already exists')

try:
    spark.sql("create schema Bank_Data.silver")
except:
    print('silver schema already exists')

try:
    spark.sql("create schema Bank_Data.gold;")
except:
    print('gold schema already exists')

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE Bank_Data.bronze.customer_data (
# MAGIC     customer_id STRING,
# MAGIC     name STRING,
# MAGIC     email STRING,
# MAGIC     phone STRING,
# MAGIC     address STRING,
# MAGIC     credit_score INT,
# MAGIC     join_date DATE,
# MAGIC     last_update TIMESTAMP
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE Bank_Data.bronze.transaction_data (
# MAGIC     transaction_id STRING,
# MAGIC     customer_id STRING,
# MAGIC     branch_id STRING,
# MAGIC     channel STRING,
# MAGIC     transaction_type STRING,
# MAGIC     amount DOUBLE,
# MAGIC     currency STRING,
# MAGIC     timestamp TIMESTAMP,
# MAGIC     status STRING
# MAGIC );
# MAGIC